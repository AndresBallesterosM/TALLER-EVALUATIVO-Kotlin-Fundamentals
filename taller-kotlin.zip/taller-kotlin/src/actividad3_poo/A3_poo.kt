
// Nombre: Carlos Andrés
// Fecha: 17/02/2026
// Descripción: Mini inventario usando clase Producto con métodos.


class Producto(val nombre: String, val precio: Int, var stock: Int) {

    fun vender(cantidad: Int): Boolean {
        if (cantidad <= 0) return false
        return if (stock >= cantidad) {
            stock -= cantidad
            true
        } else {
            false
        }
    }

    fun reponer(cantidad: Int) {
        if (cantidad > 0) {
            stock += cantidad
        }
    }

    override fun toString(): String {
        return "$nombre - Precio: $precio - Stock: $stock"
    }
}

fun main() {

    val producto1 = Producto("Teclado", 80000, 10)
    val producto2 = Producto("Mouse", 40000, 5)

    producto1.vender(3)
    producto2.vender(6)
    producto2.reponer(10)

    println(producto1)
    println(producto2)
}


// Salida esperada:
// Teclado - Precio: 80000 - Stock: 7
// Mouse - Precio: 40000 - Stock: 15


