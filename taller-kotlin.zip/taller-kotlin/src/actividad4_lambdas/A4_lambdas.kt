
// Nombre: Carlos Andrés
// Fecha: 17/02/2026
//Descripción: Filtro de productos usando lambdas y función de orden superior.


data class Producto(val nombre: String, val precio: Int, val stock: Int)

fun filtrarProductos(
    productos: List<Producto>,
    criterio: (Producto) -> Boolean
): List<Producto> {
    return productos.filter(criterio)
}

fun main() {

    val productos = listOf(
        Producto("Laptop", 2500000, 3),
        Producto("Audífonos", 150000, 0),
        Producto("Monitor", 900000, 5),
        Producto("Teclado", 120000, 0)
    )

    val caros = filtrarProductos(productos) { it.precio > 500000 }
    val agotados = filtrarProductos(productos) { it.stock == 0 }

    println("Productos caros:")
    caros.forEach { println(it) }

    println("\nProductos agotados:")
    agotados.forEach { println(it) }
}


// Salida esperada:
// Productos caros:
// Producto(nombre=Laptop, precio=2500000, stock=3)
// Producto(nombre=Monitor, precio=900000, stock=5)

// Productos agotados:
// Producto(nombre=Audífonos, precio=150000, stock=0)
// Producto(nombre=Teclado, precio=120000, stock=0)

