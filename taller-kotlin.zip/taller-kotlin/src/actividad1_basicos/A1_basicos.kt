
 // Nombre: Carlos Andrés Ballesteros Muñoz
 // Fecha: 17/02/2026
 // Descripción: Programa básico en Kotlin que muestra un perfil personal
 // y calcula el Índice de Masa Corporal (IMC) usando funciones.


fun calcularIMC(pesoKg: Double, alturaM: Double): Double {
    return pesoKg / (alturaM * alturaM)
}

fun presentacion(nombre: String, edad: Int, ciudad: String): String {
    return "Hola, soy $nombre ($edad) de $ciudad."
}

fun main() {

    // Variables
    val nombre = "Andrés"
    val edad = 21
    val ciudad = "Manizales"
    val alturaM = 1.78
    val pesoKg = 68.0

    // Llamado de funciones
    val textoPresentacion = presentacion(nombre, edad, ciudad)
    val imc = calcularIMC(pesoKg, alturaM)

    // Salida en consola
    println(textoPresentacion)
    println("IMC: %.2f".format(imc))
}


//Ejemplo de salida:

// Hola, soy Andrés (21) de Manizales.
// IMC: 21.46



