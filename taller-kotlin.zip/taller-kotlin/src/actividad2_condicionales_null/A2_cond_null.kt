
// Nombre: Carlos Andrés
// Fecha: 17/02/2026
// Descripción: Cálculo de tarifa de envío usando condicionales y nullabilidad.


fun calcularEnvio(distKm: Int, cupon: String?): Int {

    val tarifaBase = when {
        distKm < 5 -> 3000
        distKm in 5..20 -> 7000
        else -> 12000
    }

    val cuponNormalizado = cupon?.uppercase()

    return when (cuponNormalizado) {
        "FREE" -> 0
        "HALF" -> tarifaBase / 2
        else -> tarifaBase
    }
}

fun main() {
    println("Caso 1: ${calcularEnvio(3, null)}")
    println("Caso 2: ${calcularEnvio(10, "HALF")}")
    println("Caso 3: ${calcularEnvio(25, "FREE")}")
}


// Salida esperada:
// Caso 1: 3000
// Caso 2: 3500
// Caso 3: 0

